# cui-writing 2.2.0 安装说明

一个自包含的学术写作技能：按崔爱娇（Aijiao Cui）论文的论证、措辞与句法起草/改写/润色论文，并制作 IEEE 图表。内含 12 个写作流程、61 份语料、742 个选页位置及精读笔记，**不需要**另装其他 skill 或任何 Python 第三方库。

## 需要什么

- 能读取本地文件并支持 Agent Skills 的代理（Codex、DeepSeek Harness、Claude Code 等）
- Python 3（仅标准库）
- 约 5 MB 磁盘

## 方式一：自动安装（推荐）

解压后，在 `cui-writing` 目录里运行：

```bash
python3 scripts/install.py
```

默认装到 `~/.agents/skills/cui-writing`——这是 Codex 与 DeepSeek Harness **共同扫描**的用户级目录，装一次两边都能用。

其他用法：

```bash
python3 scripts/install.py --list      # 查看本机存在哪些技能目录
python3 scripts/install.py --all       # 装到所有已存在的技能目录
python3 scripts/install.py --dest DIR  # 装到指定目录（DIR/cui-writing）
python3 scripts/install.py --dry-run   # 只显示会复制什么，不改动磁盘
```

安装器会先校验源包完整性，不合格就拒绝安装；安装完再跑一次校验。重复运行是安全的：只复制有变化的文件、删除目标里的陈旧文件。

## 方式二：手动安装

把整个 `cui-writing` 文件夹放进任一技能目录即可，**保留完整目录结构**，不要只复制 `SKILL.md`。

| 代理 | 用户级目录 |
|---|---|
| Codex + DeepSeek Harness（共用） | `~/.agents/skills/` |
| DeepSeek Harness 专用 | `$DSH_HOME/skills/`（默认 `~/.dsh/skills/`） |
| Codex 旧版 | `~/.codex/skills/` |
| Claude Code | `~/.claude/skills/` |
| 项目内（随仓库走） | `<项目>/.agents/skills/` 或 `<项目>/.dsh/skills/` |

DeepSeek Harness 的实际扫描优先级（由高到低）：`<项目>/.dsh/skills`、`<项目>/.agents/skills`、自定义目录、`~/.dsh/skills`、`~/.agents/skills`。

## 装完怎么确认

```bash
cd ~/.agents/skills/cui-writing
python3 scripts/check_install.py
```

应输出 `"ok": true`、`"workflows": 12`、`"documents": 61`、`"selected_page_positions": 742`，且 `required_external_skills` 与 `third_party_python_packages` 为空、`errors` 为空。

然后重启（或刷新）代理，让它重新扫描技能目录。确认方式：技能清单里出现 `cui-writing`，或直接说：

```text
使用 $cui-writing，检索一条崔老师语料，报告 ID、页码和借鉴的论证功能。
```

## 怎么用

```text
使用 $cui-writing，按崔老师的论证和口吻润色下面的 Introduction。
保留我的事实、数字、术语和引用，先调整逻辑，再修改措辞。
正文英文，修改说明中文。

【粘贴你的原稿】
```

完整场景（论证梳理、引言、Methods、润色、图表、审稿回复、投稿前检查、想法评估、文献综述）见 `references/workflows/index.md`。IEEE 图表两个流程已内置：

```text
使用 $cui-writing，调用内置 ieee-figure-table-chatgpt，根据这份 CSV 生成单栏 IEEE 风格折线图，保留真实数据，交付 SVG/PDF 与可复用脚本。
```

## 常见问题

**找不到技能。** 检查 `SKILL.md` 是否直接位于 `cui-writing/` 下（不要多嵌套一层同名目录），以及该目录是否属于上表所列位置。改完需重启代理。

**提示需要安装 Supervisor-Skills。** 本包已内置全部流程，出现该提示说明装的是旧版或没复制完整；先跑 `check_install.py`。

**`check_install.py` 报 `Changed:`。** 文件在打包后被改动过；从原始 zip 重新解压，或运行 `scripts/install.py --all` 覆盖。

**检索器跑不了。** 确认 Python 3 可用，且 `scripts/`、`assets/`、`references/` 都在。

**中文文件名解压后乱码。** 请用 2.2.0 及以后的包（已写入 UTF-8 标志）；旧包在部分解压工具上会出现该问题。

## 来源与许可

内置流程来源、原包 SHA-256 与改动记录见 `references/workflows/NOTICE.md`、`provenance.json`、`ieee-integration-provenance.json`；`SUPERVISOR-LICENSE.txt` 随包保留，字体为 SIL OFL 1.1。论文原文的再分发权利不因打包而改变——公开分发前请自行核验所含文本的授权。

## 分享给别人

直接发送整个 `cui-writing` 文件夹或 `cui-writing-standalone-2.2.0.zip`。接收方按上文安装即可，无需你本机的任何其他文件。

包内 2.2.0 起只保留相对素材根目录的路径（如 `Journals/xxx.pdf`），不含个人目录或用户名，可直接分发。仍需注意：包内含论文提取文本，公开发布前请自行确认原文的再分发授权。
