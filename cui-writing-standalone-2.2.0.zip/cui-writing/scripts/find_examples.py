#!/usr/bin/env python3
"""Retrieve complete source blocks from the user's scoped Cui writing corpus."""
import argparse,json,re,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SECTIONS={'abstract':r'^(?:abstract|摘要)', 'introduction':r'^(?:introduction|绪论|引言)', 'related-work':r'^(?:related work|literature review|background|preliminar|相关工作|文献综述)', 'discussion':r'^(?:discussion|security analysis|analysis of (?:security|overhead)|overhead|comparison|limitations)', 'methods':r'^(?:proposed|method|scheme|design|algorithm|implementation|overall)', 'results':r'^(?:experimental|experiment|evaluation|results|performance)', 'conclusion':r'^(?:conclusion|summary|总结|本章小结)', 'references':r'^(?:references|bibliography|参考文献)'}
def section_heading(text):
 if len(text)>150:return None
 if not (re.match(r'^(?:[IVX]+\.|[A-Z]\.|\d+(?:\.\d+)*[. ]|CHAPTER\s|第)',text) or text.isupper() or re.match(r'^(?:Abstract|References|Bibliography)\b',text)):return None
 n=norm(text)
 n=re.sub(r'^chapter\s+\d+\s*','',n)
 n=re.sub(r'^(?:(?:[ivx]+|[a-z]|\d+(?:\.\d+)*)(?:\.\s*|\s+))','',n)
 n=re.sub(r'^the\s+','',n)
 for sec,pat in SECTIONS.items():
  if re.search(pat,n,re.I):return sec
 return None

def norm(t):
 t=unicodedata.normalize('NFKC',t).casefold()
 return re.sub(r'\s+',' ',re.sub(r'(?<=[a-z])-\s*\n\s*(?=[a-z])','',t)).strip()
def layout_blocks(text):
 # Keep complete paragraphs. Blank-line segmentation is an approximation, not a prose reconstruction claim.
 return [b.strip() for b in re.split(r'\n\s*\n',text) if b.strip()]
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--ids',default='');p.add_argument('--pages',help='actual PDF page or inclusive range, e.g. 8-10')
 p.add_argument('--query',default='');p.add_argument('--section',choices=list(SECTIONS)+['thesis','intro','caption'])
 p.add_argument('--limit',type=int,default=4);p.add_argument('--max-chars',type=int,default=1800,help='maximum block size; blocks are omitted whole, never cut')
 p.add_argument('--inspect-pages',action='store_true',help='return all extracted blocks on explicit ID/page ranges, including short table rows; no semantic section filter')
 p.add_argument('--include-ocr-hold',action='store_true',help='show unreliable OCR only for inspection, never as verified quotation')
 a=p.parse_args()
 if a.inspect_pages and (not a.ids or not a.pages):p.error('--inspect-pages requires explicit --ids and --pages')
 if a.limit<1 or a.max_chars<1:p.error('limit and max-chars must be positive')
 ids={i.strip().upper()for i in a.ids.split(',')if i.strip()};pages=None
 if a.pages:
  if not re.fullmatch(r'\d+(?:-\d+)?',a.pages):p.error('pages must be N or N-M')
  nums=list(map(int,a.pages.split('-')));pages=(nums[0],nums[-1])
  if pages[1]<pages[0]:p.error('page range reversed')
 section='introduction'if a.section=='intro'else a.section
 q=[x for x in re.findall(r'[\w]+',norm(a.query)) if len(x)>1]
 status=json.loads((ROOT/'references/corpus-status.json').read_text())
 states={r['id']:r for r in status['documents']};hits=[];omitted=0
 for f in sorted((ROOT/'assets/corpus').glob('*.json')):
  d=json.loads(f.read_text());id=d['id']
  if ids and id not in ids:continue
  if d.get('ocr_quote_hold')and not a.include_ocr_hold:continue
  if section=='thesis'and d['group']!='Dissertation':continue
  current='abstract' if d['group']!='Dissertation'else'introduction'
  for page in d['pages']:
   if page['page'] in d.get('style_excluded_pages',[]):continue
   if a.inspect_pages:
    if not pages[0]<=page['page']<=pages[1]:continue
    full=page.get('recovered_layout_text')or'\n'.join(page['blocks'])
    rec={'id':id,'page':page['page'],'kind':'raw-page-inspection','attribution':d['attribution'],'title':d['name'],'source_path':d['path'],'text_close_read_complete':states[id]['text_close_read_complete'],'text':full}
    if page.get('visual_supplement'):rec['visual_supplement']=page['visual_supplement']
    if page.get('extraction_warnings'):rec['extraction_warnings']=page['extraction_warnings']
    hits.append((0,id,page['page'],0,rec));continue
   blocks=layout_blocks(page['recovered_layout_text'])if page.get('recovered_layout_text')else page['blocks']
   basis='L'if page.get('recovered_layout_text')else'B'
   for i,raw in enumerate(blocks,1):
    text=raw.strip();n=norm(text)
    if any(norm(marker)in n for marker in page.get('unreliable_extraction_markers',[])):continue
    is_caption=bool(re.match(r'^(?:fig(?:ure)?\.?\s*\d+|table\s*(?:[ivx]+|\d+))',n))
    heading=section_heading(text)
    if heading:current=heading
    if pages and not pages[0]<=page['page']<=pages[1]:continue
    if len(text)<(20 if section=='caption' else 90) or current=='references':continue
    if re.search(r'received (?:the )?.{0,80}(?:degree|b\.s\.|m\.s\.|ph\.d)',n) or re.match(r'^(?:copyright|authorized licensed use|personal use of this material)',n):continue
    if section=='caption' and not is_caption:continue
    if section and section not in ('thesis','caption') and current!=section:
     # Engineering articles commonly combine evaluation and discussion.
     if not (section=='discussion' and current in ('results','methods') and re.search(r'however|although|overhead|limitation|compared|trade.off|on the other hand|局限|开销|然而|相比',n)):continue
    matches=sum(1 for term in q if term in n)
    if q and not matches:continue
    if len(text)>a.max_chars:omitted+=1;continue
    score=matches*3+(d['attribution']=='first-author-paper')*.4
    hits.append((score,id,page['page'],i,{'id':id,'page':page['page'],'block':f"P{page['page']:02d}{basis}{i:02d}",'section_hint':'caption' if is_caption else current,'section_hint_is_heuristic':True,'attribution':d['attribution'],'title':d['name'],'source_path':d['path'],'block_indexing':'B: 1-based original block; L: 1-based recovered-layout segment','text_close_read_complete':states[id]['text_close_read_complete'],'ocr_quote_hold':d.get('ocr_quote_hold',False),'text':text}))
 hits.sort(key=lambda x:(-x[0],x[1],x[2],x[3]))
 print(json.dumps({'matches':[h[-1]for h in hits[:a.limit]],'candidate_count':len(hits),'whole_blocks_omitted_for_length':omitted,'note':'全文块按原提取保留；section为启发式线索，引用前须核对上下文。无匹配时不生成替代例句。'},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
