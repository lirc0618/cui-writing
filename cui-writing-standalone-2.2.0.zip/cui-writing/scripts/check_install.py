#!/usr/bin/env python3
"""Check the self-contained cui-writing package using only Python's standard library."""
import hashlib,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
 errors=[]
 manifest=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
 if manifest.get('required_external_skills') or manifest.get('python_packages'):errors.append('Unexpected external skill or Python-package requirement')
 for rec in manifest['files']:
  p=ROOT/rec['path']
  if not p.is_file():errors.append('Missing: '+rec['path']);continue
  if hashlib.sha256(p.read_bytes()).hexdigest()!=rec['sha256']:errors.append('Changed: '+rec['path'])
 workflows=manifest['bundled_workflows']
 for name in workflows:
  if not(ROOT/'references/workflows'/name/'workflow.md').is_file():errors.append('Missing workflow: '+name)
 # Only one discoverable skill entrypoint; internal workflows are plain references.
 entries=list(ROOT.rglob('SKILL.md'))
 if entries!=[ROOT/'SKILL.md']:errors.append('Unexpected nested SKILL.md entrypoint')
 files=list((ROOT/'assets/corpus').glob('*.json'));pages=0
 for p in files:
  data=json.loads(p.read_text(encoding='utf-8'));lo,hi=data['selected_pages']
  if [r['page']for r in data['pages']]!=list(range(lo,hi+1)):errors.append('Invalid page scope: '+data['id'])
  pages+=len(data['pages'])
 status=json.loads((ROOT/'references/corpus-status.json').read_text(encoding='utf-8'))
 if (len(files),pages,status['complete_documents'],status['completed_page_positions'])!=(61,742,61,742):errors.append('Corpus/status mismatch')
 # Verify real relative Markdown links in executable instructions, excluding illustrative fenced examples.
 docs=[ROOT/'SKILL.md',*(ROOT/'references/workflows').rglob('*.md')]
 for f in docs:
  body=re.sub(r'```.*?```','',f.read_text(encoding='utf-8'),flags=re.S)
  for target in re.findall(r'\]\(([^)]+)\)',body):
   if '://'in target or target.startswith(('#','mailto:')):continue
   target=target.split('#',1)[0]
   if not target:continue
   p=(f.parent/target).resolve()
   try:p.relative_to(ROOT)
   except ValueError:errors.append('Out-of-package link: '+str(f.relative_to(ROOT))+' -> '+target);continue
   if not p.exists():errors.append('Broken link: '+str(f.relative_to(ROOT))+' -> '+target)
 result={'ok':not errors,'version':manifest['version'],'required_external_skills':[],'third_party_python_packages':[],'workflows':len(workflows),'documents':len(files),'selected_page_positions':pages,'errors':errors}
 print(json.dumps(result,ensure_ascii=False,indent=2))
 return 0 if not errors else 1
if __name__=='__main__':sys.exit(main())
