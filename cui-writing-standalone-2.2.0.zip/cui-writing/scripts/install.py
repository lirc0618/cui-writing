#!/usr/bin/env python3
"""Install this skill folder into an agent's skills directory, then verify it.

Python 3 standard library only; works on macOS, Linux and Windows.

  python3 scripts/install.py                 install to ~/.agents/skills/cui-writing
  python3 scripts/install.py --list          show detected skill directories
  python3 scripts/install.py --dest DIR      install into DIR/cui-writing
  python3 scripts/install.py --all           install into every detected directory
  python3 scripts/install.py --dry-run       show what would happen, change nothing
  python3 scripts/install.py --no-verify     skip the post-install self-check

The installer refuses to install a package that fails its own integrity check,
so a truncated copy never reaches the skills directory.
"""
import argparse
import filecmp
import os
import shutil
import subprocess
import sys
from pathlib import Path

SKILL = "cui-writing"
SOURCE = Path(__file__).resolve().parents[1]

# (label, path, note). Only user-level locations that the common agents scan.
ROOTS = [
    ("Codex + DeepSeek Harness (shared)", Path.home() / ".agents" / "skills",
     "recommended: both agents scan this root"),
    ("DeepSeek Harness", Path.home() / ".dsh" / "skills", "DSH_HOME/skills"),
    ("Codex", Path.home() / ".codex" / "skills", "legacy Codex user root"),
    ("Claude Code", Path.home() / ".claude" / "skills", ""),
]


def rel_files(root):
    return sorted(p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file())


def verify(root):
    script = root / "scripts" / "check_install.py"
    if not script.is_file():
        return 1, "missing scripts/check_install.py"
    proc = subprocess.run([sys.executable, str(script)], capture_output=True, text=True)
    return proc.returncode, (proc.stdout or proc.stderr).strip()


def install(dest_root, dry_run=False):
    target = dest_root / SKILL
    if target.resolve() == SOURCE.resolve():
        print("already running from %s; nothing to copy" % target)
        return 0
    files = rel_files(SOURCE)
    existing = rel_files(target) if target.is_dir() else []
    stale = [f for f in existing if f not in set(files)]
    changed = [f for f in files if not (target / f).is_file()
               or not filecmp.cmp(SOURCE / f, target / f, shallow=False)]
    print("source : %s (%d files)" % (SOURCE, len(files)))
    print("target : %s" % target)
    print("copy   : %d changed/new, %d stale" % (len(changed), len(stale)))
    if dry_run:
        for f in changed[:20]:
            print("  + %s" % f)
        if len(changed) > 20:
            print("  ... %d more" % (len(changed) - 20))
        return 0
    dest_root.mkdir(parents=True, exist_ok=True)
    for f in files:
        src, dst = SOURCE / f, target / f
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    for f in stale:
        try:
            (target / f).unlink()
            print("  removed stale %s" % f)
        except OSError as exc:
            print("  could not remove %s (%s)" % (f, exc))
    for d in sorted((p for p in target.rglob("*") if p.is_dir()), reverse=True):
        try:
            d.rmdir()
        except OSError:
            pass
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", help="parent skills directory (skill goes into DEST/%s)" % SKILL)
    ap.add_argument("--all", action="store_true", help="install into every detected skills directory")
    ap.add_argument("--list", action="store_true", help="list detected skills directories and exit")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-verify", action="store_true")
    args = ap.parse_args()

    found = [(label, path, note) for label, path, note in ROOTS if path.is_dir()]
    if args.list:
        print("source: %s" % SOURCE)
        for label, path, note in ROOTS:
            mark = "present" if path.is_dir() else "absent "
            print("  [%s] %-36s %s %s" % (mark, label, path, ("- " + note) if note else ""))
        return 0

    code, detail = verify(SOURCE)
    if code != 0:
        print("Refusing to install: the source package fails its integrity check.\n%s" % detail)
        return 1
    print("source package check: ok")

    if args.dest:
        targets = [Path(args.dest).expanduser()]
    elif args.all:
        targets = [path for _, path, _ in found] or [ROOTS[0][1]]
        if not found:
            print("no known skills directory exists; falling back to %s" % targets[0])
    else:
        targets = [ROOTS[0][1]]

    failures = 0
    for dest_root in targets:
        print("\n== %s" % dest_root)
        failures += install(dest_root, args.dry_run)
        if args.dry_run:
            continue
        target = dest_root / SKILL
        if not args.no_verify:
            code, detail = verify(target)
            print("installed package check: %s" % ("ok" if code == 0 else "FAILED"))
            if code != 0:
                print(detail)
                failures += 1
            else:
                print("next: restart or refresh your agent, then ask for $%s" % SKILL)
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
