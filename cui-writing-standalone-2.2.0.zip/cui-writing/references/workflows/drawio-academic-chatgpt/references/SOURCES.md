# Provenance and scope

Inspired by published repositories:
- https://github.com/bahayonghang/drawio-skills
- https://github.com/bahayonghang/drawio-skills/tree/main/skills/drawio
- https://github.com/bahayonghang/drawio-skills/tree/main/skills/drawio-academic-skills
- https://journals.ieeeauthorcenter.ieee.org/create-your-ieee-journal-article/create-graphics-for-your-article/

This is an **independent, minimal ChatGPT adaptation**. It omits upstream YAML-to-draw.io Node CLI, routing engine, palettes, templates, tests and Desktop export integrations. The bundled Python helper is an original minimal JSON-to-draw.io example. For complex layouts, edit the generated XML or use an existing diagrams.net editor; upstream URLs are provenance, not a required installation step. Not endorsed by the maintainers or IEEE.
