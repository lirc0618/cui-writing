> cui-writing内置IEEE图表流程。scripts/、assets/、references/相对本workflow.md所在目录；执行helper前将SKILL_DIR解析为本目录，不是cui-writing根目录。仅使用本包文件，无需安装同名外部skill。

# Draw.io academic figures (ChatGPT adaptation)

Self-contained ChatGPT-friendly adaptation inspired by bahayonghang/drawio-skills (`drawio` and `drawio-academic-skills`). This package is **not** the full upstream Node/YAML-based CLI and does not claim feature parity. See `references/SOURCES.md`.

## Purpose

Construct scientifically accurate, editable diagrams. Generate `.drawio` XML as the canonical editable source, rather than flattening the final diagram into an AI-generated raster image. Use provided method descriptions, block relationships, formulas, node labels and connection directions; do not make up system interfaces or dataflow direction.

## Workflow

1. Classify diagram: system architecture, algorithm flow, workflow, controls, network topology, or replication from an existing user image.
2. Establish inputs and outputs; identify typed edges, signal direction, feedback loops, subsystem boundaries, legends, mathematical symbols and exact text fidelity.
3. Use limited hierarchy and a clear reading direction. Standard layouts: left-to-right processing; top-to-bottom stages; closed-loop controls with explicit return path; grouped modules for architecture. Avoid ambiguous crossovers and decorative icons unrelated to function.
4. Choose a grayscale-safe neutral palette with line style/shape differences. Never encode semantics with color alone. Ensure labels readable when printed at target single/double-column width.
5. Use `scripts/make_drawio.py` as a small, dependency-free starter when the graph can be described by JSON nodes and edges. For complex routing or paper replication, produce or manually edit `.drawio` XML instead, checking all edge connections.
6. Deliver editable `.drawio` and rendered SVG/PDF when possible; do not imply a PNG or PDF was exported unless an actual file is present. Diagrams.net Desktop/browser may be used for vector PDF export.
7. Visually inspect exported diagrams for cut-off shapes, dense labels, overlapping edges, tiny fonts, semantic errors, legend placement, CJK font fallback, and alignment. Call out unresolved visual issues.

## Input schema for helper

```json
{
  "title": "Example signal flow",
  "direction": "LR",
  "nodes": [
    {"id":"sensor","label":"Sensor"},
    {"id":"controller","label":"Controller"},
    {"id":"plant","label":"Plant"}
  ],
  "edges": [
    {"from":"sensor","to":"controller","label":"measurement"},
    {"from":"controller","to":"plant","label":"command"}
  ]
}
```

Example command: `python scripts/make_drawio.py sample.json --out figure.drawio`. This does *basic auto-positioning*, not the upstream full routing engine. Use diagrams.net to review/edit and export as PDF/SVG.

## Paper checks

- Single/double-column width planned before diagram construction; prioritize readable labels and meaningful block grouping.
- Use consistent arrows and line styles. No arrow should imply a physical/algorithmic relationship absent from source material.
- Put caption outside the artwork for standard IEEE figure placement unless specifically requested otherwise.
- Include a short note of any inferences made, and always ask for correction before presenting inferred relationships as proven.

Use venue-specific style guides over defaults. This is not an IEEE-approved tool.
