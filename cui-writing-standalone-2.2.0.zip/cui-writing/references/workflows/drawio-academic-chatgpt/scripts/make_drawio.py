#!/usr/bin/env python3
"""Generate an editable diagrams.net .drawio file from a small JSON DAG.
Basic layout only; inspect and adjust connectors/layout manually for complex engineering systems.
Usage: python make_drawio.py nodes.json --out figure.drawio
"""
import argparse
import json
from collections import defaultdict, deque
from pathlib import Path
import xml.etree.ElementTree as ET


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('json_spec')
    parser.add_argument('--out', default='figure.drawio')
    args = parser.parse_args()
    spec = json.loads(Path(args.json_spec).read_text(encoding='utf-8'))
    nodes = spec.get('nodes', [])
    edges = spec.get('edges', [])
    if not nodes or len({str(n['id']) for n in nodes}) != len(nodes):
        raise SystemExit('Nodes must exist and have unique IDs')
    ids = {str(n['id']) for n in nodes}
    for edge in edges:
        if str(edge.get('from')) not in ids or str(edge.get('to')) not in ids:
            raise SystemExit('Every edge endpoint must name an existing node ID')
    directed = str(spec.get('direction', 'LR')).upper()
    if directed not in ('LR', 'TB'):
        raise SystemExit('direction must be LR or TB')
    parents = defaultdict(list)
    children = defaultdict(list)
    indegree = {i: 0 for i in ids}
    for e in edges:
        u, v = str(e['from']), str(e['to'])
        children[u].append(v)
        parents[v].append(u)
        indegree[v] += 1
    todo = deque([str(n['id']) for n in nodes if indegree[str(n['id'])] == 0])
    levels = {str(n['id']): 0 for n in nodes}
    seen = 0
    while todo:
        x = todo.popleft()
        seen += 1
        for y in children[x]:
            levels[y] = max(levels[y], levels[x] + 1)
            indegree[y] -= 1
            if indegree[y] == 0:
                todo.append(y)
    if seen != len(nodes):
        # Feedback loops and cycles cannot be auto-laid out reliably.
        print('Warning: cycle/feedback detected; automatic positions are approximate, inspect routes manually.')
    columns = defaultdict(list)
    for n in nodes:
        columns[levels[str(n['id'])]].append(n)

    model = ET.Element('mxfile', host='app.diagrams.net', modified='2026-10-14T00:00:00.000Z',
                       agent='ChatGPT', version='24.0.0', type='device')
    diagram = ET.SubElement(model, 'diagram', name=str(spec.get('title', 'Figure 1')), id='academic-figure')
    graph = ET.SubElement(diagram, 'mxGraphModel', dx='1200', dy='800', grid='1', gridSize='10',
                          guides='1', tooltips='1', connect='1', arrows='1', fold='1',
                          page='1', pageScale='1', pageWidth='1169', pageHeight='827', math='0', shadow='0')
    root = ET.SubElement(graph, 'root')
    ET.SubElement(root, 'mxCell', id='0')
    ET.SubElement(root, 'mxCell', id='1', parent='0')
    shapes = {}
    for depth, items in sorted(columns.items()):
        for offset, n in enumerate(items):
            identifier = str(n['id'])
            shapes[identifier] = 'node_' + identifier
            width = max(110, min(210, len(str(n.get('label', identifier))) * 7 + 30))
            if directed == 'LR':
                px = 55 + 255 * depth
                py = 65 + 125 * offset
            else:
                px = 55 + 240 * offset
                py = 60 + 150 * depth
            c = ET.SubElement(root, 'mxCell', id=shapes[identifier],
                              value=str(n.get('label', identifier)),
                              style=('rounded=1;whiteSpace=wrap;html=1;fillColor=#F5F5F5;'
                                     'strokeColor=#222222;fontColor=#111111;fontFamily=Helvetica;'
                                     'fontSize=14;strokeWidth=1.5;align=center;verticalAlign=middle;'),
                              vertex='1', parent='1')
            ET.SubElement(c, 'mxGeometry', x=str(px), y=str(py), width=str(width), height='64', **{'as': 'geometry'})
    for ix, e in enumerate(edges):
        a, b = str(e['from']), str(e['to'])
        cell = ET.SubElement(root, 'mxCell', id=f'edge_{ix}', value=str(e.get('label', '')),
                             style=('edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;'
                                    'jettySize=auto;html=1;strokeWidth=1.6;strokeColor=#333333;'
                                    'endArrow=block;endFill=1;fontSize=12;fontColor=#111111;'
                                    'labelBackgroundColor=#FFFFFF;'),
                             edge='1', parent='1', source=shapes[a], target=shapes[b])
        ET.SubElement(cell, 'mxGeometry', relative='1', **{'as':'geometry'})
    output = Path(args.out)
    output.parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(model).write(output, encoding='utf-8', xml_declaration=True)
    print(f'Created {output}; open in diagrams.net and inspect routing/typography at paper size.')


if __name__ == '__main__':
    main()
