# 内置写作工作流

这些是cui-writing自带的资料，不是待安装的外部skills。按当前任务只读取相应workflow.md及其中需要的参考文件。模块间转交表示在本包继续读本地文件，不是让用户安装或显式调用另一个技能。

|任务|内置流程|
|---|---|
|规划论文论证与方法/贡献对应|[tech-paper-template](tech-paper-template/workflow.md)|
|起草或重组引言|[intro-drafter](intro-drafter/workflow.md)|
|起草其他章节、全文及有事实依据的回复正文|[paper-writer](paper-writer/workflow.md)|
|忠实润色、中文转英文及口吻适配|[paper-polish](paper-polish/workflow.md)|
|论文图的设计与说明|[figure-designer](figure-designer/workflow.md)|
|审稿意见分析与回复策略|[rebuttal-guidance](rebuttal-guidance/workflow.md)|
|用户要求的投稿前审阅|[pre-submission-reviewer](pre-submission-reviewer/workflow.md)|
|用户要求的研究想法评估|[idea-evaluator](idea-evaluator/workflow.md)|
|Benchmark论文规划|[benchmark-paper-template](benchmark-paper-template/workflow.md)|
|用户要求的文献综述与研究梳理|[deep-research](deep-research/workflow.md)|

## 适用顺序

当前用户要求和研究事实优先，其次cui-writing主入口/作者规则，再是此处通用工作流。六段引言、三项挑战、贡献数、字数、词语列表等都是需要按稿件取舍的组织辅助，不强制覆盖用户体裁与作者实际写法。只需润色就不擅自扩展为立项评估、全文审计、文献调查或新的实验任务。

外部能力按环境提供：新文献事实用现有搜索工具核验；无检索时限用用户已给来源并说明范围。独立引用复核可使用已授权且可用的代理；不可用时按内置verification-ladder同上下文核验并如实说明。画图工具从现有能力选择，图设计建议本身不以安装特定商业软件为前提。它们是任务相关能力，不是外部skill或Python包依赖。

来源与许可：[NOTICE.md](NOTICE.md)。

## IEEE图表扩展

- [drawio-academic-chatgpt](drawio-academic-chatgpt/workflow.md)：可编辑架构/流程/工程拓扑；内置JSON到.drawio工具。
- [ieee-figure-table-chatgpt](ieee-figure-table-chatgpt/workflow.md)：真实数据图表/图注；内置CSV到SVG/PDF工具及字体，无第三方Python包必需项。

来源为用户提供的两个适配包，范围与改动见[ieee-integration-provenance.json](ieee-integration-provenance.json)。不是IEEE官方工具；版面要求以用户目标期刊为准。
