# 内置工作流来源

来源：[HKUSTDial/Supervisor-Skills](https://github.com/HKUSTDial/Supervisor-Skills)，本机已安装副本。上游方法论署名为Yuyu Luo及贡献者；完整原仓库许可见[SUPERVISOR-LICENSE.txt](SUPERVISOR-LICENSE.txt)。各原文件frontmatter中的许可声明另保留在provenance.json，不将其与论文原文的权利混同。

适配：将所需工作流及其全部Markdown参考资料嵌入cui-writing；原SKILL.md改为workflow.md，移除技能发现frontmatter；跨模块改为包内链接；删除上游仅用于维护的同步脚本注释；增加本地路由说明。原始文件与适配文件的SHA256及改动记录见[provenance.json](provenance.json)。不暗示原作者或导师认可本适配。

这些许可说明适用于所引工作流；不替论文/书章原文授予再分发许可。
