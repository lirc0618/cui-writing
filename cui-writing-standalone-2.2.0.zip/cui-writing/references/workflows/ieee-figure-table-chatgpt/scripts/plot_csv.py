#!/usr/bin/env python3
"""CSV to reproducible line/scatter/grouped-bar SVG/PDF; Python standard library only.
Examples: python3 plot_csv.py data.csv --x SNR --y MethodA MethodB --yscale log --output figure
Missing observations remain gaps; no interpolation or invented uncertainty. Use a custom
script for error bars, multi-panel layouts, unusual transforms or nonstandard baselines.
"""
import argparse,sys,importlib.util
from pathlib import Path
_spec=importlib.util.spec_from_file_location("_ieee_vector_plot",Path(__file__).with_name("vector_plot.py"))
_backend=importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_backend)
plot=_backend.plot

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('csv');p.add_argument('--x',required=True);p.add_argument('--y',nargs='+',required=True)
    p.add_argument('--kind',choices=['line','scatter','bar'],default='line')
    p.add_argument('--xlabel');p.add_argument('--ylabel')
    p.add_argument('--yscale',choices=['linear','log'],default='linear')
    p.add_argument('--column',choices=['single','double'],default='single')
    p.add_argument('--output',default='ieee_figure');p.add_argument('--legend',choices=['auto','none'],default='auto')
    p.add_argument('--font',help='Optional Unicode TrueType font; bundled Liberation Sans is the default')
    a=p.parse_args()
    try:plot(a)
    except(ValueError,OSError)as e:p.error(str(e))
if __name__=='__main__':main()
