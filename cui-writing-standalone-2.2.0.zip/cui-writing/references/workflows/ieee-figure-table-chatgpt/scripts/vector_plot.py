"""Dependency-free vector SVG/PDF backend for small CSV line/scatter/grouped-bar figures."""
import base64,csv,hashlib,html,json,math,struct,zlib
from pathlib import Path

class Font:
    def __init__(self,path):
        self.data=Path(path).read_bytes();b=self.data
        if b[:4]not in (b'\x00\x01\x00\x00',b'true'):raise ValueError('Provide a TrueType .ttf font (TTC/OTF collections are not supported).')
        self.tables={}
        for i in range(struct.unpack_from('>H',b,4)[0]):
            tag,_,off,size=struct.unpack_from('>4sIII',b,12+i*16);self.tables[tag.decode()]=(off,size)
        h=self.tables['head'][0];self.units=struct.unpack_from('>H',b,h+18)[0];self.bbox=struct.unpack_from('>hhhh',b,h+36)
        h=self.tables['hhea'][0];self.asc,self.desc=struct.unpack_from('>hh',b,h+4);count=struct.unpack_from('>H',b,h+34)[0]
        h=self.tables['hmtx'][0];self.widths=[struct.unpack_from('>H',b,h+i*4)[0]for i in range(count)]
        h=self.tables['cmap'][0];candidates=[]
        for i in range(struct.unpack_from('>H',b,h+2)[0]):
            platform,enc,off=struct.unpack_from('>HHI',b,h+4+i*8);pos=h+off;fmt=struct.unpack_from('>H',b,pos)[0]
            if platform in(0,3)and fmt in(4,12):candidates.append((fmt,pos))
        if not candidates:raise ValueError('Font has no supported Unicode cmap.')
        self.fmt,self.cmap=max(candidates);self.used=set();self.psname='PlotFont'
        if 'name'in self.tables:
            pos=self.tables['name'][0];total,storage=struct.unpack_from('>HH',b,pos+2)
            for i in range(total):
                platform,encoding,language,nameid,size,offset=struct.unpack_from('>HHHHHH',b,pos+6+12*i)
                if nameid==6:
                    raw=b[pos+storage+offset:pos+storage+offset+size]
                    name=raw.decode('utf-16-be'if platform in(0,3)else'latin-1',errors='ignore')
                    self.psname=''.join(c for c in name if c.isascii()and(c.isalnum()or c in '-_'))or'PlotFont'
                    if platform==3:break
    def glyph(self,code):
        b=self.data;p=self.cmap
        if self.fmt==12:
            for i in range(struct.unpack_from('>I',b,p+12)[0]):
                lo,hi,g=struct.unpack_from('>III',b,p+16+i*12)
                if lo<=code<=hi:return g+code-lo
            return 0
        n=struct.unpack_from('>H',b,p+6)[0]//2;end=p+14;start=end+2*n+2;delta=start+2*n;offset=delta+2*n
        for i in range(n):
            hi=struct.unpack_from('>H',b,end+2*i)[0];lo=struct.unpack_from('>H',b,start+2*i)[0]
            if lo<=code<=hi:
                d=struct.unpack_from('>h',b,delta+2*i)[0];r=struct.unpack_from('>H',b,offset+2*i)[0]
                if not r:return(code+d)&65535
                g=struct.unpack_from('>H',b,offset+2*i+r+2*(code-lo))[0]
                return(g+d)&65535 if g else 0
        return 0
    def check(self,text):
        for c in text:
            if ord(c)>65535 or not self.glyph(ord(c)):raise ValueError('Bundled font does not cover '+repr(c)+'; supply --font with a suitable Unicode TrueType font.')
            self.used.add(ord(c))
    def width(self,text,size):
        return sum(self.widths[min(self.glyph(ord(c)),len(self.widths)-1)]for c in text)*size/self.units

class Canvas:
    def __init__(self,w,h,font):self.w=w;self.h=h;self.font=font;self.svg=[];self.pdf=[]
    def path(self,pts,color='#222222',width=.8,dash='',fill='none',closed=False):
        if not pts:return
        d='M '+' L '.join(f'{x:.3f},{y:.3f}'for x,y in pts)+(' Z'if closed else'')
        self.svg.append(f'<path d="{d}" fill="{fill}" stroke="{color}" stroke-width="{width}"'+(f' stroke-dasharray="{dash}"'if dash else'')+'/>')
        rgb=' '.join(f'{int(color[i:i+2],16)/255:.4f}'for i in(1,3,5));cmd=f'q {rgb} RG {width} w [{dash.replace(","," ")}] 0 d '
        if fill!='none':cmd+=' '.join(f'{int(fill[i:i+2],16)/255:.4f}'for i in(1,3,5))+' rg '
        cmd+=f'{pts[0][0]:.3f} {pts[0][1]:.3f} m '+' '.join(f'{x:.3f} {y:.3f} l'for x,y in pts[1:])
        self.pdf.append(cmd+(' h'if closed else'')+(' B'if fill!='none'else' S')+' Q')
    def text(self,x,y,text,size=8,anchor='middle',angle=0):
        text=str(text);self.font.check(text)
        self.svg.append(f'<text x="{x:.3f}" y="{y:.3f}" text-anchor="{anchor}" font-size="{size}"'+(f' transform="rotate({angle} {x} {y})"'if angle else'')+'>'+html.escape(text)+'</text>')
        a=math.radians(angle);c=math.cos(a);s=math.sin(a);shift=self.font.width(text,size)*({'middle':.5,'end':1}.get(anchor,0));x-=c*shift;y-=s*shift
        self.pdf.append(f'q 0 0 0 rg BT /F1 {size} Tf {c:.6f} {s:.6f} {s:.6f} {-c:.6f} {x:.3f} {y:.3f} Tm <{text.encode("utf-16-be").hex()}> Tj ET Q')
    def marker(self,x,y,i):
        r=2.2
        if i%3==0:pts=[(x+r*math.cos(j*math.pi/8),y+r*math.sin(j*math.pi/8))for j in range(16)]
        elif i%3==1:pts=[(x-r,y-r),(x+r,y-r),(x+r,y+r),(x-r,y+r)]
        else:pts=[(x,y-r*1.2),(x+r,y+r),(x-r,y+r)]
        self.path(pts,width=.65,fill='#FFFFFF',closed=True)
    def save(self,base):
        font64=base64.b64encode(self.font.data).decode()
        svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w/72}in" height="{self.h/72}in" viewBox="0 0 {self.w} {self.h}"><style>@font-face{{font-family:PlotFont;src:url(data:font/ttf;base64,{font64})}}text{{font-family:PlotFont,sans-serif;fill:#111}}</style><rect width="100%" height="100%" fill="white"/>'+''.join(self.svg)+'</svg>'
        base.with_suffix('.svg').write_text(svg,encoding='utf-8')
        self.save_pdf(base.with_suffix('.pdf'))
    def save_pdf(self,path):
        f=self.font;objects=[]
        def obj(data):objects.append(data.encode()if isinstance(data,str)else data);return len(objects)
        def stream(data,extra=''):
            packed=zlib.compress(data);return b'<< /Length '+str(len(packed)).encode()+b' /Filter /FlateDecode '+extra.encode()+b' >>\nstream\n'+packed+b'\nendstream'
        obj('<< /Type /Catalog /Pages 2 0 R >>');obj('<< /Type /Pages /Count 1 /Kids [3 0 R] >>')
        obj(f'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {self.w} {self.h}] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>')
        obj(stream((f'q 1 0 0 -1 0 {self.h} cm\n'+'\n'.join(self.pdf)+'\nQ').encode()))
        obj(f'<< /Type /Font /Subtype /Type0 /BaseFont /{f.psname} /Encoding /Identity-H /DescendantFonts [6 0 R] /ToUnicode 10 0 R >>')
        scale=lambda n:round(n*1000/f.units)
        widths=' '.join(f'{c} [{scale(f.widths[min(f.glyph(c),len(f.widths)-1)])}]'for c in sorted(f.used))
        obj(f'<< /Type /Font /Subtype /CIDFontType2 /BaseFont /{f.psname} /CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >> /FontDescriptor 7 0 R /CIDToGIDMap 9 0 R /DW 1000 /W ['+widths+'] >>')
        obj(f'<< /Type /FontDescriptor /FontName /{f.psname} /Flags 32 /FontBBox [{" ".join(str(scale(x))for x in f.bbox)}] /ItalicAngle 0 /Ascent {scale(f.asc)} /Descent {scale(f.desc)} /CapHeight {scale(f.asc)} /StemV 80 /FontFile2 8 0 R >>')
        obj(stream(f.data,f'/Length1 {len(f.data)}'))
        gid=bytearray((max(f.used,default=0)+1)*2)
        for c in f.used:struct.pack_into('>H',gid,c*2,f.glyph(c))
        obj(stream(bytes(gid)))
        cmap='/CIDInit /ProcSet findresource begin 12 dict begin begincmap /CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def /CMapName /PlotUnicode def /CMapType 2 def 1 begincodespacerange <0000> <FFFF> endcodespacerange\n'
        used=sorted(f.used)
        for i in range(0,len(used),100):
            chunk=used[i:i+100];cmap+=f'{len(chunk)} beginbfchar\n'+'\n'.join(f'<{c:04X}> <{c:04X}>'for c in chunk)+'\nendbfchar\n'
        cmap+='endcmap CMapName currentdict /CMap defineresource pop end end';obj(stream(cmap.encode()))
        out=bytearray(b'%PDF-1.4\n%\xe2\xe3\xcf\xd3\n');offsets=[0]
        for i,data in enumerate(objects,1):offsets.append(len(out));out+=f'{i} 0 obj\n'.encode()+data+b'\nendobj\n'
        xref=len(out);out+=f'xref\n0 {len(objects)+1}\n0000000000 65535 f \n'.encode()
        out+=''.join(f'{x:010d} 00000 n \n'for x in offsets[1:]).encode();out+=f'trailer\n<< /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n'.encode();path.write_bytes(out)

def plot(args):
    src=Path(args.csv)
    with src.open(encoding='utf-8-sig',newline='')as h:
        reader=csv.DictReader(h);fields=reader.fieldnames or[]
        if len(fields)!=len(set(fields)):raise ValueError('CSV column names must be unique.')
        missing=[k for k in [args.x,*args.y]if k not in fields]
        if missing:raise ValueError('Missing columns: '+', '.join(missing))
        rows=list(reader)
        if any(None in row for row in rows):raise ValueError('CSV row has extra fields; check delimiters and quoting.')
    if not rows:raise ValueError('CSV contains no data rows.')
    def number(s,row,column):
        if s is None or not s.strip():return None
        try:v=float(s)
        except ValueError:raise ValueError(f'Non-numeric value at CSV row {row}, column {column}: {s!r}')
        if not math.isfinite(v):raise ValueError(f'Non-finite value at CSV row {row}, column {column}')
        return v
    xs=list(range(len(rows)))if args.kind=='bar'else[number(r[args.x],i+2,args.x)for i,r in enumerate(rows)]
    ys=[[number(r[y],i+2,y)for i,r in enumerate(rows)]for y in args.y]
    if args.yscale=='log'and any(v is not None and v<=0 for series in ys for v in series):raise ValueError('Log scale requires all nonmissing Y values > 0.')
    valid=[v for series in ys for x,v in zip(xs,series)if x is not None and v is not None]
    if not valid:raise ValueError('No finite paired X/Y values.')
    font=Font(args.font or Path(__file__).resolve().parents[1]/'assets/fonts/LiberationSans-Regular.ttf')
    w,h=(252,180)if args.column=='single'else(515.52,259.2);c=Canvas(w,h,font)
    legends=args.legend!='none'and len(args.y)>1;legend_rows=len(args.y)if legends else 0
    left,right,top,bottom=48,w-10,10+legend_rows*10,h-34
    if bottom-top<60:raise ValueError('Too many legend entries; use double column or a custom multi-panel script.')
    xmin,xmax=min(x for x in xs if x is not None),max(x for x in xs if x is not None)
    if args.kind=='bar':xmin-=.6;xmax+=.6
    elif xmin==xmax:xmin-=.5;xmax+=.5
    else:pad=(xmax-xmin)*.04;xmin-=pad;xmax+=pad
    if args.yscale=='log':
        lo,hi=math.floor(math.log10(min(valid))),math.ceil(math.log10(max(valid)))
        if lo==hi:hi+=1
        step=max(1,math.ceil((hi-lo)/5));ticks=[10.**k for k in range(lo,hi+1,step)];ymin,ymax=lo,hi
        trans=lambda v:math.log10(v)
    else:
        lo,hi=min(valid),max(valid)
        if args.kind=='bar':lo=min(lo,0);hi=max(hi,0)
        if lo==hi:lo-=max(.5,abs(lo)*.1);hi+=max(.5,abs(hi)*.1)
        pad=(hi-lo)*.06;lo-=pad;hi+=pad;raw=(hi-lo)/4;power=10**math.floor(math.log10(raw));step=next(q*power for q in(1,2,2.5,5,10)if q*power>=raw)
        ymin=0 if args.kind=='bar'and min(valid)>=0 else math.floor(lo/step)*step;ymax=math.ceil(hi/step)*step;ticks=[ymin+i*step for i in range(round((ymax-ymin)/step)+1)];trans=lambda v:v
    X=lambda x:left+(x-xmin)/(xmax-xmin)*(right-left);Y=lambda y:bottom-(trans(y)-ymin)/(ymax-ymin)*(bottom-top)
    for v in ticks:
        y=Y(v);c.path([(left,y),(right,y)],color='#CCCCCC',width=.3);c.text(left-5,y+2.5,f'{v:.4g}',7.5,'end')
    if args.kind=='bar':xt=list(enumerate(r[args.x]for r in rows))
    else:
        rawlo=min(x for x in xs if x is not None);rawhi=max(x for x in xs if x is not None)
        if rawlo==rawhi:xt=[(rawlo,f'{rawlo:.4g}')]
        else:
            raw=(rawhi-rawlo)/4;power=10**math.floor(math.log10(raw));inc=next(q*power for q in(1,2,2.5,5,10)if q*power>=raw)
            first=math.ceil(rawlo/inc)*inc;xt=[(first+i*inc,f'{first+i*inc:.4g}')for i in range(max(0,math.floor((rawhi-first)/inc))+1)]
    if args.kind=='bar'and len(xt)>15:raise ValueError('More than 15 categories needs a custom layout; do not silently omit labels.')
    for x,label in xt:
        c.path([(X(x),bottom),(X(x),bottom+3)],width=.6);c.text(X(x),bottom+13,label,7.5)
    c.path([(left,top),(left,bottom),(right,bottom)],width=.7)
    styles=['','4 2','5 2 1 2','1 2']
    for i,(name,series)in enumerate(zip(args.y,ys)):
        if legends:
            yy=8+i*10;c.path([(left,yy),(left+18,yy)],dash=styles[i%4]);c.marker(left+9,yy,i);c.text(left+24,yy+2.5,name,7.5,'start')
        if args.kind=='bar':
            unit=(right-left)/(xmax-xmin);bw=.76*unit/len(ys)
            for x,v in zip(xs,series):
                if v is None:continue
                xx=X(x)-.38*unit+i*bw;y=Y(v);zero=Y(1 if args.yscale=='log'else 0)
                if args.yscale=='log':raise ValueError('Log-scale bars need an explicit reference baseline; use a custom script.')
                c.path([(xx,zero),(xx+bw,zero),(xx+bw,y),(xx,y)],fill=['#CCCCCC','#FFFFFF','#888888'][i%3],closed=True)
        else:
            segment=[]
            for x,v in zip(xs,series):
                if x is None or v is None:
                    if args.kind=='line':c.path(segment,dash=styles[i%4])
                    segment=[];continue
                pt=(X(x),Y(v));segment.append(pt);c.marker(*pt,i)
            if args.kind=='line':c.path(segment,dash=styles[i%4])
    c.text((left+right)/2,h-5,args.xlabel or args.x,9)
    c.text(12,(top+bottom)/2,args.ylabel or', '.join(args.y),9,angle=-90)
    base=Path(args.output);base.parent.mkdir(parents=True,exist_ok=True);c.save(base)
    missing_count=sum(v is None for series in ys for v in series)+sum(v is None for v in xs)
    meta={'backend':'stdlib-vector','source_file':src.name,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'kind':args.kind,'x':args.x,'y':args.y,'rows':len(rows),'missing_values':missing_count,'missing_policy':'gaps retained; no interpolation','width_inches':w/72,'height_inches':h/72,'pdf_font_embedded':True,'outputs':[str(base.with_suffix('.pdf')),str(base.with_suffix('.svg'))]}
    base.with_suffix('.plot.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
    print(json.dumps(meta,ensure_ascii=False,indent=2))
