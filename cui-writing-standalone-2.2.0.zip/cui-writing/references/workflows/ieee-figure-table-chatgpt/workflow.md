> cui-writing内置IEEE图表流程。scripts/、assets/、references/相对本workflow.md所在目录；执行helper前将SKILL_DIR解析为本目录，不是cui-writing根目录。仅使用本包文件，无需安装同名外部skill。

# IEEE figure and table workflow (ChatGPT adaptation)

Adapted as a self-contained ChatGPT workflow inspired by CloudWave818/ieee-skills, particularly `ieee-figure-table`. Not an official IEEE tool or a verbatim copy. See `references/SOURCES.md`.

## Route task

Distinguish (a) plot existing real data, (b) review a provided figure, (c) create an architecture/flow chart, (d) produce a manuscript-ready caption or table. Do not invent measurements, baselines, significance, uncertainty, or engineering assumptions. If no data was provided, draw only explicitly labeled mockups or return reusable code and list required inputs.

## Figure contract

Before creating a final figure, determine the engineering claim, data source and units, x/y definitions, comparison fairness, target single/double column, intended manuscript and export format. Use single column ~3.5 in, double ~7.16 in as common planning widths (verify with the target journal's current author instructions). Readability at final size matters more than full-screen appearance.

## Practical workflow

1. If user attaches CSV/XLSX/MAT/JSON, inspect data shape, missing values, uncertainty and units first; do not silently interpolate measurements.
2. Use the bundled dependency-free vector backend, Matplotlib when already available, or another reproducible plotting backend, never a generative image as the final quantitative data representation.
3. Start from `scripts/plot_csv.py` for simple CSV line/scatter/grouped-bar charts and adjust for technical meaning. It uses only Python standard library and the bundled licensed TrueType font: no Matplotlib/Pandas install is required. It exports actual vector SVG/PDF with an embedded PDF font and a source-hash/settings JSON. It preserves missing observations as gaps and rejects invalid/nonpositive log data. This is a starter, not a one-size-fits-all plot engine; error bars and multi-panel plots need a custom script using the supplied real inputs.
4. Prefer vector PDF for camera-ready and editable source code. Export PNG 300+ dpi when needed, at journal-specified resolution. SVG is a useful working format but may not be an accepted final submission format for every IEEE journal.
5. Distinguish curves using different markers/dashes, not only colors. Check grayscale legibility; avoid overlapping legends, ambiguous axes, hidden negative outcomes, cropped annotations and misleading axis limits.
6. Check mathematical notation, condition labels, sample counts, uncertainty interval/error bar definitions, significant digits, graph labels and panel lettering.
7. Write informative captions explaining what is compared, experimental conditions and meaning of error bars. Never imply results prove more than they do.
8. Verify saved files exist and visually review them at intended print width when tools are available. Mention every unverified requirement.

## Deliverables

- Data-driven figures: at least reusable plotting script + PDF; PNG and SVG when relevant; caption draft, source assumptions, QA notes.
- Chart review: issue severity, concrete corrective actions and revised style plan.
- Architecture diagram: read [drawio-academic-chatgpt](../drawio-academic-chatgpt/workflow.md), bundled locally; do not install or invoke a sibling skill.

Follow all journal-specific instructions over defaults, and do not claim IEEE approval.

## Local paths and export

Resolve scripts/ and assets/ relative to this SKILL.md (or embedded workflow.md), not the working directory. Run `python3 "$SKILL_DIR/scripts/plot_csv.py" data.csv --x SNR --y MethodA MethodB --output figure`. The basic helper produces PDF/SVG, not PNG; create PNG only through a renderer available in the environment and verify the actual file. Plain Unicode labels use the bundled Liberation Sans font; if a glyph is unavailable, provide a suitable TrueType font via --font rather than silently replacing it. Advanced math typesetting uses an available scientific plotting backend or publication tool.
