# Provenance and scope

This independent ChatGPT-friendly adaptation draws its task taxonomy and quality priorities from:
- https://github.com/CloudWave818/ieee-skills
- https://github.com/CloudWave818/ieee-skills/tree/main/skills/ieee-figure-table
- https://journals.ieeeauthorcenter.ieee.org/create-your-ieee-journal-article/create-graphics-for-your-article/

It is **not** the full upstream Codex skills distribution. It does not include all upstream manifests, fragments, scripts, or agents, and will not update automatically. The included `plot_csv.py` is an original lightweight helper for ChatGPT use. IEEE and the upstream maintainers do not endorse this package.

## Local integration changes (2026-10-21)

Replaced the Matplotlib/Pandas-only CSV starter with a Python-standard-library vector backend for line/scatter/grouped-bar plots. Bundled the unmodified Liberation Sans font and its OFL license; PDF embeds the font and SVG embeds it for consistent preview. Added source-hash/settings metadata and input validation. Original scientific evidence and journal-specific checks remain. This does not implement the full upstream package or imply IEEE approval.
