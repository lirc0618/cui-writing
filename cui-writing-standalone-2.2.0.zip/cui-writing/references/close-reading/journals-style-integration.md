# J03–J16 全文精读后的写作规则与反例（供 voice / sections 整合）

2026-10-21，14篇195页实际全文阅读完成，逐篇笔记和原件/文本页哈希审计见本目录 manifest-journals.json、journals-self-audit.json。只在抽取缺公式/表或需核实处查原页，manifest visual_checked按实际查看记录。J17/J18不在本代理完成声明内。以下是合著语料支持的写作习惯，不将所有句子独占归属某一作者。

## 可进入 voice 的规则

1. **把限定写在机制附近，而不是统一塞到末尾limitations。** “However, if ...”“provided that ...”“Except for ...”经常标记方法生效/失效所需条件。J14 P8B1–B2：static仍安全依赖boundary plaintext不能正确输入；J15 P8B4–B8：cost0边是FF简单交换例外；J16 P6B11：well-formed hard IP变为有test set/内部修改能力后，第一法能被识别/抹除。
2. **给出因果桥，少堆抽象好处。** 先说哪个自由度没有改（scan order/functional netlist），再推local routing/可控代价；先说mismatch被latched，再解释循环偶然匹配为何不会停止。J14 P8B3–P9B5、J16 P13B5–P14B2。
3. **允许自身前作和当前初版成为反例。** J14从SOSD→TMOSA→DOSD；J16 P3B1承认旧scan-order/SfT水印路由及不可控开销，P6B11用第一法失效推出第二法。迁移的是诚实推理和新模块必要性，不是强行每稿安排“攻破自己”。
4. **性能改善同时带范围、分母和代价。** J15 P11B2总体area较低但delay略高；J16 P13B3前作area总是较低，本文timing只23/38较好；J14 P12B1–B4同一固定gate增量在pipelined/iterative百分比不同。习惯可写“in general ... but ...”“for k out of n ...”。禁止把salient/best tradeoff改成全指标最优。
5. **区分实际测量、模型计算、机制论证、引用和预期。** J15 P11B2的P&R为已有文献/expected，非当轮新实测；J16 P13B3比较[22]同tools/library重做，[23]directly excerpted；J13 P12–P15 rawPUF模拟/既有119chip数据和全方案逻辑仿真层次不同。保留“are expected”“we conservatively presume”“excerpted”的证据角色。
6. **数字必须保留对应对象和统计单位。** J05八ciphertexts 15.112ms→平均1.9ms，不能变单item独立end-to-end；J16 P12B6的34是watermarked cases而非34独立设计；J12 nominal容量/特征interHD/closed-set accuracy/open-set拒绝是不同指标。
7. **经验零事件用样本协议叙述，不扩张成概率定理。** J04 1000随机无误报；J15 P11B4–P12B1 200随机+ATPG无全匹配；J16 P14B2–B3 10^6随机零匹配：可写“none was observed under ...”，不能写“false positives are impossible”。
8. **避免把预测关联写成物理因果。** J07/J10学习next-toggle，attention/RTG是预测依赖；J08 statistical coherency亦有伪相关和frozen register失败。用“indicates / is associated with / is used to identify”须依研究证据，不复制“physical relationship recovered”而跳过netlist证实。
9. **保留可观测性/测试接口前提。** J07–J11合法scan访问、partial scan可见范围；J15/J16 blocking使现场读取失败但水印仍存在，需要逆向/拆封恢复。detectability与水印存在、不可移除是三个判断。
10. **措辞要校准，源稿夸张、病句或内部矛盾不属于必须模仿的风格。** J06标题Optimal但正文heuristic；J10无参数宣传与阈值/tops/K选择并存；J11runtime“tens of minutes”与表max19568s不符；J14“unconditional”依当时攻击范围；J16“zero-overhead”仍有test-power增量。学习具体推理句法，不继承这些词的强度。

## 可进入 sections 的组织规则

- **Introduction / related work：**用具体旧法改动及其残留代价收窄到本稿自由度，而非统一“prior work is inefficient”。J16分类static/dynamic→FSM/DfT→reorder的route冲突→fixed-order本地连接；J14则按已有防御→test-only漏洞→新的静态方案再自我攻击。六步逻辑是反向分析工具，原文并不固定六自然段。
- **Preliminaries：**只引入后面机制会依赖的量和假设，并标旧知与新增。J16 Ti/NTi已有，新增capture替换LT/LNT；该段直接导出独立连接选择和新attack线索，不是装饰性背景。
- **Method：**常见模块对齐是“构造/嵌入→数据或协议适配→检测/恢复→代价/韧性”；J16两法复用8FF/W101同例隔离差异，J15用7FF例落实随机位置到贪心路径，再另加公开认证协议解决直接公开P泄漏问题。并非每篇都必须这四小节，取决于真实模块。
- **Analysis：**按威胁能力或攻击目的分类，再给机制/反例/计算，显式说计算模型。J16 forgery/modification/removal九攻击，与Pc/Pλ两个非对抗真实性指标分开；ghost-search智能反推复杂度仍open。不让概率公式替代所有攻击讨论。
- **Experiments：**先定义tool/library/benchmark/test set、分母/单位、归一化或重做方式，再表→趋势→反例→适用规模。J05频率归一化比较不是原raw latency胜负；J15/J16大电路摊薄趋势不能覆盖小design异常；J07/J10/J11 register识别率和transition恢复率不互相代替。
- **Conclusion：**回扣关键失效点/机制/证据及可选择代价；承认未来工作尚未实现。J12 million-scale ANN/crossdevice、J08完整STG、J15hierarchical watermark都不能回写为已完成系统能力。

## 需要写作分身主动阻止的跨论文错误合并

- J07/J11与J10的self-loop行为规则并不相同，不建立“Cui总用某一self-loop判据”。
- J13把FSM恢复困难作为历史假设，后续J07–J11确实研究恢复；不能把旧假设持久化成不可能定理。
- J15 SfT已融合functional/test以提高拆分成本；J16主要fixed-order SFF，SfT是可结合选项，不能把两个防御默认已同时实现。
- J15 Pc含位置空间组合因子，J16 Pc=2^-m；两篇模型定义不同，不选一个变全语料统一公式。
- J03 AACHA tighter部分case、J06 AAIC不总减数据、J12 digital black-box imitation可在多query后成功但physical reprint拒绝，都必须保留反例所在实验对象。

本摘要只提供可检索行为规则。实际起草仍须针对新稿事实重新确定威胁模型、实验分母、证据强度与作者归属，不能把上述技术结论带到不相关新研究。
